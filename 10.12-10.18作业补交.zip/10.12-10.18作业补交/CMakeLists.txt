cmake_minimum_required(VERSION 3.20)
project(opencv_basic LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(OpenCV_DIR "D:/opencv/build/x64/vc16/lib")
find_package(OpenCV REQUIRED)
#message(STATUS "OpenCV_DIR = ${OpenCV_DIR}")
#message(STATUS "OpenCV_INCLUDE  = ${OpenCV_INCLUDE_DIRS}")
#message(STATUS "OpenCV_LIBS  = ${OpenCV_LIBS}")
configure_file(${CMAKE_CURRENT_SOURCE_DIR}/config.h.in
			${CMAKE_CURRENT_BINARY_DIR}/config.h @ONLY)
add_executable(opencv_basic main.cpp)
target_include_directories(opencv_basic PRIVATE
				${CMAKE_CURRENT_BINARY_DIR}
				${OpenCV_INCLUDE_DIRS})

#target_include_directories(opencv_basic PRIVATE ${OpenCV_INCLUDE_DIRS})
target_link_libraries(opencv_basic PRIVATE ${OpenCV_LIBS})
add_custom_command(TARGET opencv_basic POST_BUILD
			COMMAND ${CMAKE_COMMAND} -E copy_if_different
			"D:/opencv/build/x64/vc16/bin/opencv_world4140d.dll"
			"$<TARGET_FILE_DIR:opencv_basic>")