#include <opencv2/opencv.hpp>
#include <opencv2/core/utils/logger.hpp>
#include <filesystem>
#include <iostream>
#include <string>
#include"config.h"
int main() {
    cv::utils::logging::setLogLevel(cv::utils::logging::LOG_LEVEL_SILENT);
    const std::string inputPath = "images/input.png";//PROJECT_SRC_DIR;
    const std::string outDir    = "output";

    cv::Mat img = cv::imread(inputPath);
    if (img.empty()) {
        std::cerr << "[error] read failed: " << inputPath << "\n";
        std::cerr << "current working dir: " << std::filesystem::current_path() << "\n";
        return -1;
    }

    std::error_code ec;
    std::filesystem::create_directories(outDir, ec);
    if (ec) {
        std::cerr << "[error] cannot create " << outDir << ": " << ec.message() << "\n";
        return -1;
    }
    //cv::resize(img.clone(), img, cv::Size(), 0.5, 0.5);
    std::cout << "size     = " << img.cols << " x " << img.rows << "\n";
    std::cout << "channels = " << img.channels() << "\n";

    cv::Mat gray, hsv;
    cv::cvtColor(img, gray, cv::COLOR_BGR2GRAY);

    cv::Mat gaugray,g1;
    cv::GaussianBlur(gray, gaugray, cv::Size(5, 5), 0);
    cv::threshold(gaugray, g1,120 ,255, cv::THRESH_BINARY_INV);
    cv::imwrite(outDir + "/fixed_blur_gray.png", gaugray);
    cv::imwrite(outDir + "/fixed_mask_gray.png", g1);

    cv::Mat med, m1;
    cv::medianBlur(img, med, 5);
    cv::cvtColor(med, hsv, cv::COLOR_BGR2HSV);
    cv::inRange(hsv, cv::Scalar(35, 80, 80), cv::Scalar(85, 255, 255), m1);
    cv::imwrite(outDir + "/fixed_blur_color.png", med);
    cv::imwrite(outDir + "/fixed_mask_hsv.png", m1);

    cv::Mat kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(3, 3));
    cv::Mat k1 = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(7, 7));
    cv::Mat ero, dil, open, close;
    cv::erode(m1, ero, kernel);
    cv::dilate(m1, dil, kernel);
    cv::morphologyEx(m1, open, cv::MORPH_OPEN, kernel);
    cv::morphologyEx(m1, close, cv::MORPH_CLOSE, k1);

    cv::imwrite(outDir + "/fixed_eroded.png", ero);
    cv::imwrite(outDir + "/fixed_dilated.png", dil);
    cv::imwrite(outDir + "/fixed_opened.png", open);
    cv::imwrite(outDir + "/fixed_closed.png", close);

    std::vector<std::vector<cv::Point> >sc;
    cv::findContours(open, sc, cv::RETR_EXTERNAL, cv::CHAIN_APPROX_SIMPLE);
    cv::Mat canvas = img.clone();
    int num = 0;
    for (auto& c : sc) {
        double area = cv::contourArea(c);
        if (area < 100)continue;
        std::cout << "area : " << area << '\n';

        cv::Rect r = cv::boundingRect(c);
        cv::RotatedRect rr = cv::minAreaRect(c);
        cv::rectangle(canvas, r, cv::Scalar(0, 255, 0), 2);
        
        cv::Point2f pts[4];
        rr.points(pts);
        std::vector<cv::Point> ip;
        for (auto& p : pts)ip.push_back(cv::Point((int)p.x, (int)p.y));
        cv::polylines(canvas, std::vector<std::vector<cv::Point> > {ip},
            true, cv::Scalar(255, 0, 255), 2);

        cv::Moments m = cv::moments(c);
        if (m.m00 != 0) {
            double cx = m.m10 / m.m00;
            double cy = m.m01 / m.m00;
            cv::circle(canvas, cv::Point((int)cx, (int)cy), 2, cv::Scalar(0, 0, 255), -1);
            std::cout << "Point(x,y) :" << "( " << cx << " , " << cy << " )" << '\n';
        }
        num++;
    }
    std::cout << "target number:" << num << '\n';
    cv::imwrite(outDir + "/fixed_result.png", canvas);
    return 0;
}
